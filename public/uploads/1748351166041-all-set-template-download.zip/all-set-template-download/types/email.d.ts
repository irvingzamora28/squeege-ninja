export interface EmailRecord {
  id: number
  email: string
  created_at: string
}
