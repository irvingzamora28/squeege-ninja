const headerNavLinks = [
  { href: '/', title: 'Home' },
  { href: '/blog', title: 'Blog' },
  { href: '/tags', title: 'Tags' },
  { href: '/projects', title: 'Projects' },
  { href: '/about', title: 'About' },
  { href: '#features', title: 'Features' },
  { href: '#pricing', title: 'Pricing' },
  { href: '#contact', title: 'Contact' },
]

export default headerNavLinks
